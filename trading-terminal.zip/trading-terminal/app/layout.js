import './globals.css';

export const metadata = {
  title: 'APEX TERMINAL — Trading Signal Dashboard',
  description: 'Professional trading signals for XAUUSD & BTCUSD with real-time TradingView charts',
  icons: { icon: '/favicon.ico' },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
