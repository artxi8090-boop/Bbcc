'use client';

import { useState, useEffect, useRef, useCallback } from 'react';

// ─── DEFAULT INDICATOR SETTINGS ─────────────────────────────────────────────
const DEFAULT_SETTINGS = {
  ema_fast: 8,
  ema_slow: 21,
  ema_trend: 200,
  rsi_period: 14,
  rsi_ob: 70,
  rsi_os: 30,
  macd_fast: 12,
  macd_slow: 26,
  macd_signal: 9,
  bb_period: 20,
  bb_dev: 2,
  stoch_k: 14,
  stoch_d: 3,
  atr_period: 14,
  adx_period: 14,
  show_volume: true,
  show_bb: true,
};

// ─── PAIR CONFIG ─────────────────────────────────────────────────────────────
const PAIRS = {
  XAUUSD: {
    tv_symbol: 'OANDA:XAUUSD',
    label: 'XAU/USD',
    color: '#d4a017',
    colorDim: 'rgba(212,160,23,0.12)',
    class: 'xau',
    desc: 'GOLD / US DOLLAR',
  },
  BTCUSD: {
    tv_symbol: 'BINANCE:BTCUSDT',
    label: 'BTC/USD',
    color: '#00d4ff',
    colorDim: 'rgba(0,212,255,0.1)',
    class: 'btc',
    desc: 'BITCOIN / US DOLLAR',
  },
};

const TIMEFRAMES = [
  { label: '1M', tv: '1' },
  { label: '5M', tv: '5' },
  { label: '15M', tv: '15' },
  { label: '1H', tv: '60' },
  { label: '4H', tv: '240' },
  { label: '1D', tv: 'D' },
];

// ─── SIGNAL SIMULATION (replace with real API in production) ─────────────────
function generateSignals(pair, tf, settings, seed) {
  const base = ((seed * 9301 + 49297) % 233280) / 233280;
  const r = (o = 0) => ((((seed + o) * 1664525 + 1013904223) & 0xffffffff) >>> 0) / 4294967296;

  const rsiVal = 30 + r(1) * 40 + (pair === 'XAUUSD' ? 5 : -5);
  const macdHist = (r(2) - 0.5) * 2;
  const emaFastAboveSlow = r(3) > 0.4;
  const priceAboveTrend = r(4) > 0.35;
  const bbPos = r(5) * 100;
  const stochK = 10 + r(6) * 80;
  const adxVal = 15 + r(7) * 45;
  const volumeSpike = r(8) > 0.6;

  const rsiSig = rsiVal < settings.rsi_os ? 'buy' : rsiVal > settings.rsi_ob ? 'sell' : 'neutral';
  const macdSig = macdHist > 0.3 ? 'buy' : macdHist < -0.3 ? 'sell' : 'neutral';
  const emaSig = emaFastAboveSlow ? 'buy' : 'sell';
  const trendSig = priceAboveTrend ? 'buy' : 'sell';
  const bbSig = bbPos < 20 ? 'buy' : bbPos > 80 ? 'sell' : 'neutral';
  const stochSig = stochK < 20 ? 'buy' : stochK > 80 ? 'sell' : 'neutral';
  const adxSig = adxVal > 25 ? (emaSig === 'buy' ? 'buy' : 'sell') : 'neutral';
  const volSig = volumeSpike ? emaSig : 'neutral';

  const signals = [rsiSig, macdSig, emaSig, trendSig, bbSig, stochSig, adxSig, volSig];
  const buys = signals.filter(s => s === 'buy').length;
  const sells = signals.filter(s => s === 'sell').length;
  const overall = buys >= 5 ? 'buy' : sells >= 5 ? 'sell' : buys > sells ? 'buy' : sells > buys ? 'sell' : 'neutral';
  const strength = Math.max(buys, sells) / signals.length;

  return {
    overall,
    strength,
    buys,
    sells,
    neutrals: signals.length - buys - sells,
    indicators: [
      { id: 'RSI', name: `RSI (${settings.rsi_period})`, signal: rsiSig, value: rsiVal.toFixed(1), desc: `OB:${settings.rsi_ob} OS:${settings.rsi_os}` },
      { id: 'MACD', name: `MACD (${settings.macd_fast},${settings.macd_slow},${settings.macd_signal})`, signal: macdSig, value: macdHist.toFixed(4), desc: 'Histogram' },
      { id: 'EMA_CROSS', name: `EMA Cross (${settings.ema_fast}/${settings.ema_slow})`, signal: emaSig, value: emaSig === 'buy' ? 'BULL' : 'BEAR', desc: 'Fast vs Slow' },
      { id: 'EMA_TREND', name: `EMA Trend (${settings.ema_trend})`, signal: trendSig, value: trendSig === 'buy' ? 'ABOVE' : 'BELOW', desc: 'Price Position' },
      { id: 'BB', name: `Bollinger Bands (${settings.bb_period},${settings.bb_dev})`, signal: bbSig, value: `${bbPos.toFixed(0)}%`, desc: 'Band Position' },
      { id: 'STOCH', name: `Stochastic (${settings.stoch_k},${settings.stoch_d})`, signal: stochSig, value: `${stochK.toFixed(1)}`, desc: '%K Value' },
      { id: 'ADX', name: `ADX (${settings.adx_period})`, signal: adxSig, value: `${adxVal.toFixed(1)}`, desc: adxVal > 25 ? 'TRENDING' : 'RANGING' },
      { id: 'VOL', name: 'Volume', signal: volSig, value: volumeSpike ? 'HIGH' : 'NORMAL', desc: 'Volume Spike' },
    ],
  };
}

// ─── TRADINGVIEW WIDGET ───────────────────────────────────────────────────────
function TradingViewWidget({ symbol, timeframe, pair }) {
  const containerRef = useRef(null);
  const scriptRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;
    containerRef.current.innerHTML = '';

    const container = document.createElement('div');
    container.className = 'tradingview-widget-container__widget';
    container.style.height = '100%';
    container.style.width = '100%';
    containerRef.current.appendChild(container);

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.async = true;
    script.type = 'text/javascript';

    const accentColor = pair === 'XAUUSD' ? '#d4a017' : '#00d4ff';

    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: symbol,
      interval: timeframe,
      timezone: 'Etc/UTC',
      theme: 'dark',
      style: '1',
      locale: 'en',
      backgroundColor: 'rgba(7, 7, 9, 0)',
      gridColor: 'rgba(255, 255, 255, 0.04)',
      hide_top_toolbar: false,
      hide_legend: false,
      save_image: false,
      calendar: false,
      hide_volume: false,
      support_host: 'https://www.tradingview.com',
      studies: [
        `MASimple@tv-builtin;length=${20}`,
        'RSI@tv-builtin',
        'MACD@tv-builtin',
        'BollingerBandsR@tv-builtin',
      ],
      container_id: 'tradingview_widget',
    });

    containerRef.current.appendChild(script);
    scriptRef.current = script;

    return () => {
      if (containerRef.current) containerRef.current.innerHTML = '';
    };
  }, [symbol, timeframe]);

  return (
    <div
      ref={containerRef}
      className="tradingview-widget-container"
      style={{ height: '100%', width: '100%' }}
    />
  );
}

// ─── SIGNAL ICON ─────────────────────────────────────────────────────────────
function SignalIcon({ type, size = 16 }) {
  if (type === 'buy') return <svg width={size} height={size} viewBox="0 0 16 16" fill="none"><path d="M8 3L13 8H10V13H6V8H3L8 3Z" fill="var(--green)" /></svg>;
  if (type === 'sell') return <svg width={size} height={size} viewBox="0 0 16 16" fill="none"><path d="M8 13L3 8H6V3H10V8H13L8 13Z" fill="var(--red)" /></svg>;
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none"><rect x="3" y="7.5" width="10" height="1.5" rx="0.75" fill="var(--gold)" /><rect x="6" y="5" width="4" height="1.5" rx="0.75" fill="var(--gold)" opacity="0.5" /><rect x="6" y="9.5" width="4" height="1.5" rx="0.75" fill="var(--gold)" opacity="0.5" /></svg>;
}

// ─── MAIN SIGNAL DASHBOARD ────────────────────────────────────────────────────
export default function SignalDashboard() {
  const [activePair, setActivePair] = useState('XAUUSD');
  const [activeTf, setActiveTf] = useState('60');
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [showSettings, setShowSettings] = useState(false);
  const [seed, setSeed] = useState(42);
  const [signals, setSignals] = useState(null);

  // Refresh signals every 30 seconds
  useEffect(() => {
    const newSeed = Date.now() % 100000;
    setSeed(newSeed);
  }, [activePair, activeTf]);

  useEffect(() => {
    const id = setInterval(() => setSeed(Date.now() % 100000), 30000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    setSignals(generateSignals(activePair, activeTf, settings, seed));
  }, [activePair, activeTf, settings, seed]);

  const pair = PAIRS[activePair];

  const overallColor = signals?.overall === 'buy' ? 'var(--green)'
    : signals?.overall === 'sell' ? 'var(--red)'
    : 'var(--gold)';

  return (
    <div>
      {/* ─── Header ─── */}
      <div className="page-header">
        <div>
          <div className="page-title">SIGNAL DASHBOARD</div>
          <div className="page-subtitle">REAL-TIME MULTI-INDICATOR ANALYSIS • AUTO-REFRESH 30S</div>
        </div>
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <div className="pair-selector">
            {Object.entries(PAIRS).map(([key, p]) => (
              <button
                key={key}
                className={`pair-btn ${p.class} ${activePair === key ? 'active' : ''}`}
                onClick={() => setActivePair(key)}
              >
                {key === 'XAUUSD' ? '◆ ' : '₿ '}{p.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ─── Main Grid ─── */}
      <div className="signal-grid">
        {/* ─── Chart Card ─── */}
        <div className="card chart-card">
          <div className="card-header">
            <div className="card-title">
              <span style={{ color: pair.color, fontSize: 16 }}>
                {activePair === 'XAUUSD' ? '◆' : '₿'}
              </span>
              <span className="card-title-accent">{pair.label}</span>
              <span style={{ color: 'var(--text-dim)', fontSize: 10 }}>—</span>
              <span>{pair.desc}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div className="timeframe-row">
                {TIMEFRAMES.map(tf => (
                  <button
                    key={tf.tv}
                    className={`tf-btn ${activeTf === tf.tv ? 'active' : ''}`}
                    onClick={() => setActiveTf(tf.tv)}
                  >
                    {tf.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="chart-container" style={{ flex: 1, minHeight: 0, height: '100%' }}>
            <TradingViewWidget
              symbol={pair.tv_symbol}
              timeframe={activeTf}
              pair={activePair}
            />
          </div>
        </div>

        {/* ─── Signal Panel ─── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Overall Signal */}
          <div className="card">
            <div className="card-header">
              <div className="card-title">◈ OVERALL SIGNAL</div>
              <button
                className="settings-btn"
                onClick={() => setShowSettings(s => !s)}
                title="Configure Indicators"
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <circle cx="7" cy="7" r="2.5" stroke="currentColor" strokeWidth="1.3"/>
                  <path d="M7 1v2M7 11v2M1 7h2M11 7h2M2.93 2.93l1.42 1.42M9.65 9.65l1.42 1.42M2.93 11.07l1.42-1.42M9.65 4.35l1.42-1.42" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
                </svg>
              </button>
            </div>

            {signals && (
              <div className="overall-signal">
                <div className={`signal-ring ${signals.overall}`}>
                  <div className="signal-ring-border" />
                  <div className="signal-ring-inner">
                    {signals.overall === 'buy' ? 'BUY' : signals.overall === 'sell' ? 'SELL' : 'WAIT'}
                  </div>
                </div>
                <div className="signal-strength-bar">
                  <div
                    className={`signal-strength-fill ${signals.overall}`}
                    style={{ width: `${signals.strength * 100}%` }}
                  />
                </div>
                <div className="signal-label">
                  SIGNAL STRENGTH: {(signals.strength * 100).toFixed(0)}%
                </div>
              </div>
            )}

            <div className="stats-row">
              <div className="stat-item">
                <div className="stat-value buy">{signals?.buys ?? 0}</div>
                <div className="stat-label">BUY</div>
              </div>
              <div className="stat-item">
                <div className="stat-value neutral">{signals?.neutrals ?? 0}</div>
                <div className="stat-label">NEUTRAL</div>
              </div>
              <div className="stat-item">
                <div className="stat-value sell">{signals?.sells ?? 0}</div>
                <div className="stat-label">SELL</div>
              </div>
            </div>

            {/* Settings Panel */}
            {showSettings && (
              <div className="settings-panel">
                <div className="settings-title">⚙ INDICATOR PARAMETERS</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                  {[
                    { key: 'ema_fast', label: 'EMA Fast' },
                    { key: 'ema_slow', label: 'EMA Slow' },
                    { key: 'ema_trend', label: 'EMA Trend' },
                    { key: 'rsi_period', label: 'RSI Period' },
                    { key: 'rsi_ob', label: 'RSI OB' },
                    { key: 'rsi_os', label: 'RSI OS' },
                    { key: 'macd_fast', label: 'MACD Fast' },
                    { key: 'macd_slow', label: 'MACD Slow' },
                    { key: 'macd_signal', label: 'MACD Signal' },
                    { key: 'bb_period', label: 'BB Period' },
                    { key: 'bb_dev', label: 'BB Dev' },
                    { key: 'stoch_k', label: 'Stoch %K' },
                    { key: 'stoch_d', label: 'Stoch %D' },
                    { key: 'atr_period', label: 'ATR Period' },
                    { key: 'adx_period', label: 'ADX Period' },
                  ].map(({ key, label }) => (
                    <div key={key} className="setting-row">
                      <span className="setting-label">{label}</span>
                      <input
                        type="number"
                        className="setting-input"
                        value={settings[key]}
                        min={1}
                        onChange={e => setSettings(s => ({ ...s, [key]: Number(e.target.value) }))}
                      />
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: 8, display: 'flex', gap: 16 }}>
                  {[
                    { key: 'show_bb', label: 'Show BB' },
                    { key: 'show_volume', label: 'Volume' },
                  ].map(({ key, label }) => (
                    <div key={key} className="setting-row" style={{ flex: 1 }}>
                      <span className="setting-label">{label}</span>
                      <div
                        className={`toggle ${settings[key] ? 'on' : ''}`}
                        onClick={() => setSettings(s => ({ ...s, [key]: !s[key] }))}
                      />
                    </div>
                  ))}
                </div>
                <button
                  style={{
                    marginTop: 10, padding: '7px 14px', borderRadius: 6,
                    border: '1px solid var(--border)', background: 'var(--gold-dim)',
                    color: 'var(--gold-light)', fontFamily: 'var(--font-mono)',
                    fontSize: 10, letterSpacing: 1, cursor: 'pointer', width: '100%',
                  }}
                  onClick={() => setSettings(DEFAULT_SETTINGS)}
                >
                  RESET DEFAULTS
                </button>
              </div>
            )}
          </div>

          {/* Indicators List */}
          <div className="card" style={{ flex: 1 }}>
            <div className="card-header">
              <div className="card-title">◇ INDICATORS</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text-dim)', letterSpacing: 1 }}>
                8 ACTIVE
              </div>
            </div>
            <div className="indicators-list">
              {signals?.indicators.map((ind, i) => (
                <div
                  key={ind.id}
                  className={`indicator-row ${ind.signal}`}
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  <SignalIcon type={ind.signal} size={14} />
                  <span className="indicator-name">{ind.name}</span>
                  <span className="indicator-value">{ind.value}</span>
                  <span className={`indicator-signal ${ind.signal}`}>
                    {ind.signal.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
