'use client';

import { useState, useEffect } from 'react';

// ─── CHECKLIST DATA ──────────────────────────────────────────────────────────
const CHECKLIST_GROUPS = [
  {
    id: 'market',
    label: '📊 Market Context',
    color: '#d4a017',
    items: [
      { id: 'trend_d', text: 'Confirmed trend on Daily', sub: 'Price above/below key EMA 200 on D1', type: 'required' },
      { id: 'trend_h4', text: 'H4 structure aligned with Daily trend', sub: 'Higher highs/lows (uptrend) or Lower highs/lows (downtrend)', type: 'required' },
      { id: 'no_news', text: 'No major news within 30 minutes', sub: 'Check Forex Factory — avoid NFP, CPI, FOMC, Fed Speak', type: 'blocker' },
      { id: 'session', text: 'Active trading session open', sub: 'London or New York session preferred (avoid Asian dead zones)', type: 'required' },
      { id: 'spread', text: 'Spread is normal / acceptable', sub: 'XAUUSD < 25 pips | BTCUSD < $80 spread', type: 'required' },
    ],
  },
  {
    id: 'setup',
    label: '🎯 Trade Setup',
    color: '#00d4ff',
    items: [
      { id: 'entry_signal', text: 'Clear entry signal confirmed', sub: 'Minimum 5/8 indicators aligned in same direction', type: 'required' },
      { id: 'key_level', text: 'Entry near key support/resistance', sub: 'S/R level, round number, or significant swing point', type: 'required' },
      { id: 'pattern', text: 'Price action pattern present', sub: 'Pin bar, engulfing, inside bar, or break of structure', type: 'optional' },
      { id: 'multi_tf', text: 'Multi-timeframe confluence', sub: 'At least 2 timeframes agree on direction', type: 'required' },
      { id: 'liquidity', text: 'Not chasing — no FOMO entry', sub: 'Entry is at a logical zone, not mid-air / extended move', type: 'blocker' },
    ],
  },
  {
    id: 'risk',
    label: '🛡️ Risk Management',
    color: '#ff3366',
    items: [
      { id: 'sl_set', text: 'Stop Loss placed at logical level', sub: 'Behind swing high/low, structure, or volatility point', type: 'required' },
      { id: 'rr_ratio', text: 'Risk:Reward ≥ 1:2', sub: 'Never enter trade below 1:2 RR — no exceptions', type: 'required' },
      { id: 'position_size', text: 'Position size calculated correctly', sub: 'Max risk 1-2% of account per trade', type: 'required' },
      { id: 'corr', text: 'No correlated positions open', sub: 'Check existing trades — XAUUSD & USDJPY correlation', type: 'blocker' },
      { id: 'dd', text: 'Daily drawdown limit not exceeded', sub: 'Stop trading if daily loss > 3% of account', type: 'blocker' },
    ],
  },
  {
    id: 'psychology',
    label: '🧠 Psychology',
    color: '#00e676',
    items: [
      { id: 'plan', text: 'Trade matches my trading plan', sub: 'Not deviating from strategy — trading plan is documented', type: 'required' },
      { id: 'emotional', text: 'I am calm and focused (no FOMO/Fear)', sub: 'No emotional state: anger, revenge, euphoria, boredom', type: 'blocker' },
      { id: 'well_rested', text: 'Well rested and alert', sub: 'No trading while tired, sick, or distracted', type: 'required' },
      { id: 'loss_recovery', text: 'Not trying to recover a loss', sub: 'Revenge trading is the #1 account killer — be honest', type: 'blocker' },
      { id: 'journal', text: 'Trade recorded in journal', sub: 'Screenshot + notes: setup, entry, SL, TP, rationale', type: 'optional' },
    ],
  },
];

// ─── CATEGORY COLORS ─────────────────────────────────────────────────────────
const TYPE_CONFIG = {
  required: { icon: '●', label: 'REQUIRED' },
  blocker: { icon: '✕', label: 'BLOCKER' },
  optional: { icon: '○', label: 'OPTIONAL' },
};

export default function ChecklistPage() {
  const [checked, setChecked] = useState({});
  const [notes, setNotes] = useState('');
  const [pair, setPair] = useState('XAUUSD');

  // Load from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('apex_checklist');
      if (saved) {
        const data = JSON.parse(saved);
        setChecked(data.checked || {});
        setNotes(data.notes || '');
        setPair(data.pair || 'XAUUSD');
      }
    } catch {}
  }, []);

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('apex_checklist', JSON.stringify({ checked, notes, pair }));
    } catch {}
  }, [checked, notes, pair]);

  const allItems = CHECKLIST_GROUPS.flatMap(g => g.items);
  const requiredItems = allItems.filter(i => i.type === 'required');
  const blockerItems = allItems.filter(i => i.type === 'blocker');

  const toggleItem = (id) => {
    setChecked(s => ({ ...s, [id]: !s[id] }));
  };

  // Scoring
  const checkedRequired = requiredItems.filter(i => checked[i.id]).length;
  const blockedItems = blockerItems.filter(i => checked[i.id]);
  const hasBlocker = blockedItems.length > 0;
  const requiredPct = requiredItems.length > 0 ? checkedRequired / requiredItems.length : 0;
  const totalChecked = allItems.filter(i => checked[i.id]).length;
  const totalItems = allItems.length;

  const readinessPct = hasBlocker ? 0 : Math.round(requiredPct * 100);
  const canTrade = readinessPct === 100 && !hasBlocker;

  const verdict = canTrade ? 'EXECUTE' : hasBlocker ? 'DO NOT TRADE' : readinessPct >= 70 ? 'ALMOST READY' : 'NOT READY';
  const verdictColor = canTrade ? 'var(--green)' : hasBlocker ? 'var(--red)' : readinessPct >= 70 ? 'var(--gold)' : 'var(--red)';

  const resetAll = () => {
    setChecked({});
    setNotes('');
  };

  // SVG dial
  const R = 68;
  const C = 2 * Math.PI * R;
  const offset = C - (C * readinessPct) / 100;

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <div className="page-title">TRADE CHECKLIST</div>
          <div className="page-subtitle">COMPLETE ALL REQUIREMENTS BEFORE ENTERING A TRADE</div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: 11,
            color: 'var(--text-dim)', letterSpacing: 1,
          }}>
            PAIR:
          </div>
          <div className="pair-selector">
            {['XAUUSD', 'BTCUSD'].map(p => (
              <button
                key={p}
                className={`pair-btn ${p === 'XAUUSD' ? 'xau' : 'btc'} ${pair === p ? 'active' : ''}`}
                onClick={() => setPair(p)}
              >
                {p === 'XAUUSD' ? '◆ XAU/USD' : '₿ BTC/USD'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="checklist-layout">
        {/* Left: Checklist groups */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {CHECKLIST_GROUPS.map(group => (
            <div key={group.id} className="card checklist-card">
              <div className="checklist-group-label">
                <span style={{ fontSize: 14 }}>{group.label.split(' ')[0]}</span>
                {group.label.split(' ').slice(1).join(' ')}
                <span style={{
                  marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 9,
                  color: 'var(--text-dim)', letterSpacing: 1,
                }}>
                  {group.items.filter(i => checked[i.id]).length}/{group.items.length}
                </span>
              </div>

              {group.items.map(item => {
                const isChecked = !!checked[item.id];
                const isBlocker = item.type === 'blocker';
                return (
                  <div
                    key={item.id}
                    className={`checklist-item ${isChecked ? (isBlocker ? 'blocked' : 'checked') : ''}`}
                    onClick={() => toggleItem(item.id)}
                  >
                    <div className={`check-box ${isChecked ? (isBlocker ? 'blocked-box' : 'checked') : ''}`}>
                      {isChecked && (
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          {isBlocker
                            ? <path d="M3 3L9 9M9 3L3 9" stroke="var(--red)" strokeWidth="1.8" strokeLinecap="round"/>
                            : <path d="M2 6L5 9L10 3" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                          }
                        </svg>
                      )}
                    </div>
                    <div className="check-text">
                      <div className="check-text-main">{item.text}</div>
                      <div className="check-text-sub">{item.sub}</div>
                    </div>
                    <div style={{
                      fontFamily: 'var(--font-mono)', fontSize: 8,
                      letterSpacing: 1,
                      color: item.type === 'required' ? 'var(--text-dim)'
                        : item.type === 'blocker' ? 'rgba(255,51,102,0.5)'
                        : 'rgba(0,212,255,0.4)',
                      padding: '2px 6px',
                      border: `1px solid ${item.type === 'required' ? 'var(--border-subtle)'
                        : item.type === 'blocker' ? 'rgba(255,51,102,0.2)'
                        : 'rgba(0,212,255,0.2)'}`,
                      borderRadius: 4,
                      whiteSpace: 'nowrap',
                    }}>
                      {TYPE_CONFIG[item.type].label}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}

          {/* Notes */}
          <div className="card" style={{ padding: 16 }}>
            <div className="card-header" style={{ marginBottom: 12, border: 'none', padding: 0 }}>
              <div className="card-title">✏ TRADE NOTES</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text-dim)', letterSpacing: 1 }}>
                {pair} — {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
              </div>
            </div>
            <textarea
              className="notes-area"
              placeholder="Record your trade rationale, key levels, risk notes, observations..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
            />
          </div>
        </div>

        {/* Right: Readiness Meter (sticky) */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="card readiness-card" style={{ position: 'sticky', top: 88 }}>
            {/* Dial */}
            <div className="readiness-dial">
              <svg viewBox="0 0 160 160">
                <circle
                  cx="80" cy="80" r={R}
                  fill="none"
                  stroke="var(--bg-secondary)"
                  strokeWidth="8"
                />
                <circle
                  cx="80" cy="80" r={R}
                  fill="none"
                  stroke={verdictColor}
                  strokeWidth="8"
                  strokeDasharray={C}
                  strokeDashoffset={offset}
                  strokeLinecap="round"
                  style={{
                    transition: 'stroke-dashoffset 0.7s cubic-bezier(0.4,0,0.2,1), stroke 0.4s',
                    filter: `drop-shadow(0 0 8px ${verdictColor}40)`,
                  }}
                />
              </svg>
              <div className="readiness-percent">
                <div className="readiness-number" style={{ color: verdictColor }}>
                  {readinessPct}
                </div>
                <div className="readiness-text">READY %</div>
              </div>
            </div>

            <div className="readiness-verdict" style={{ color: verdictColor }}>
              {verdict}
            </div>

            <div className="readiness-sub">
              {canTrade
                ? 'All conditions met. You may enter the trade with full confidence.'
                : hasBlocker
                  ? `BLOCKER ACTIVE: ${blockedItems.map(i => i.text).join(', ')}. Do not enter until resolved.`
                  : `${requiredItems.length - checkedRequired} required conditions remaining. Complete checklist before trading.`
              }
            </div>

            {/* Category breakdown */}
            <div className="progress-items">
              {CHECKLIST_GROUPS.map(group => {
                const total = group.items.filter(i => i.type !== 'optional').length;
                const done = group.items.filter(i => checked[i.id] && i.type !== 'optional').length;
                const pct = total > 0 ? (done / total) * 100 : 0;
                return (
                  <div key={group.id} className="progress-item">
                    <span style={{ minWidth: 80, fontSize: 9, letterSpacing: 1 }}>
                      {group.label.split(' ').slice(1).join(' ').split(' ')[0].toUpperCase()}
                    </span>
                    <div className="progress-bar-mini">
                      <div
                        className="progress-fill-mini"
                        style={{
                          width: `${pct}%`,
                          background: pct === 100 ? 'var(--green)' : group.color,
                        }}
                      />
                    </div>
                    <span style={{ minWidth: 30, textAlign: 'right', fontSize: 9 }}>
                      {done}/{total}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="divider" />

            {/* Legend */}
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginBottom: 16 }}>
              {[
                { color: 'var(--text-dim)', borderColor: 'var(--border-subtle)', label: 'REQUIRED' },
                { color: 'rgba(255,51,102,0.5)', borderColor: 'rgba(255,51,102,0.2)', label: 'BLOCKER' },
                { color: 'rgba(0,212,255,0.4)', borderColor: 'rgba(0,212,255,0.2)', label: 'OPTIONAL' },
              ].map(({ color, borderColor, label }) => (
                <div key={label} style={{
                  fontFamily: 'var(--font-mono)', fontSize: 8,
                  color, padding: '2px 7px',
                  border: `1px solid ${borderColor}`,
                  borderRadius: 4, letterSpacing: 1,
                }}>
                  {label}
                </div>
              ))}
            </div>

            <button className="reset-btn" onClick={resetAll}>
              ↺ RESET CHECKLIST
            </button>

            {/* Stats */}
            <div style={{
              marginTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr',
              gap: 8, textAlign: 'center',
            }}>
              <div style={{
                padding: '10px 8px', borderRadius: 8,
                background: 'var(--green-dim)', border: '1px solid rgba(0,230,118,0.12)',
              }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 20, color: 'var(--green)', fontWeight: 700 }}>
                  {totalChecked}
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text-dim)', letterSpacing: 1 }}>
                  CHECKED
                </div>
              </div>
              <div style={{
                padding: '10px 8px', borderRadius: 8,
                background: 'var(--bg-glass)', border: '1px solid var(--border-subtle)',
              }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 20, color: 'var(--text-primary)', fontWeight: 700 }}>
                  {totalItems - totalChecked}
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text-dim)', letterSpacing: 1 }}>
                  REMAINING
                </div>
              </div>
            </div>
          </div>

          {/* Disclaimer */}
          <div style={{
            padding: '12px 16px',
            borderRadius: 10,
            border: '1px solid rgba(212,160,23,0.1)',
            background: 'rgba(212,160,23,0.04)',
          }}>
            <div style={{
              fontFamily: 'var(--font-mono)', fontSize: 9,
              color: 'var(--gold)', letterSpacing: 1.5,
              marginBottom: 6,
            }}>
              ⚠ DISCLAIMER
            </div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: 11, color: 'var(--text-dim)', lineHeight: 1.7 }}>
              This tool is for educational purposes only. Trading involves risk of loss.
              Always use proper risk management and never trade with money you cannot afford to lose.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
