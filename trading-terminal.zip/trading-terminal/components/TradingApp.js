'use client';

import { useState, useEffect } from 'react';
import SignalDashboard from './SignalDashboard';
import ChecklistPage from './ChecklistPage';

export default function TradingApp() {
  const [activePage, setActivePage] = useState('signals');
  const [time, setTime] = useState('');

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-US', {
        hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit',
        timeZone: 'UTC'
      }) + ' UTC');
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="app-layout">
      {/* ─── NAVBAR ─── */}
      <nav className="navbar">
        <div className="navbar-logo">
          <div className="logo-icon">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M2 14L6 8L9 11L12 6L16 10" stroke="#d4a017" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="16" cy="5" r="2" fill="#d4a017" opacity="0.6"/>
              <circle cx="2" cy="14" r="1.5" fill="#00d4ff" opacity="0.4"/>
            </svg>
          </div>
          <div>
            <div className="logo-text">APEX</div>
            <div className="logo-sub">TRADING TERMINAL</div>
          </div>
        </div>

        <div className="navbar-center">
          <button
            className={`nav-tab ${activePage === 'signals' ? 'active' : ''}`}
            onClick={() => setActivePage('signals')}
          >
            ◈ Signal Dashboard
          </button>
          <button
            className={`nav-tab ${activePage === 'checklist' ? 'active' : ''}`}
            onClick={() => setActivePage('checklist')}
          >
            ✦ Trade Checklist
          </button>
        </div>

        <div className="navbar-right">
          <div className="live-badge">
            <div className="live-dot" />
            LIVE
          </div>
          <div className="time-display">{time}</div>
        </div>
      </nav>

      {/* ─── PAGE CONTENT ─── */}
      <main className="main-content">
        {activePage === 'signals' && <SignalDashboard />}
        {activePage === 'checklist' && <ChecklistPage />}
      </main>
    </div>
  );
}
