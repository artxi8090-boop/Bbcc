# APEX TRADING TERMINAL

A world-class trading signal dashboard for **XAUUSD** and **BTCUSD** with real-time TradingView charts, multi-indicator signals, and a professional trade checklist.

## Features

- 📊 **Live TradingView Charts** — Advanced charts with built-in indicators (EMA, RSI, MACD, Bollinger Bands)
- 🎯 **8 Signal Indicators** — RSI, MACD, EMA Cross, EMA Trend, Bollinger Bands, Stochastic, ADX, Volume
- ⚙️ **Fully Configurable** — Adjust all indicator parameters in real-time
- ✅ **Trade Checklist** — 20 professional criteria across Market, Setup, Risk, and Psychology
- 🛡️ **Readiness Meter** — Visual dial showing trade readiness percentage
- 💾 **Auto-save** — Checklist state persists across sessions
- 🌙 **Dark Luxury Design** — Professional terminal aesthetic

## Quick Deploy to Vercel

### Option 1: GitHub + Vercel (Recommended)

1. Push this folder to a GitHub repository
2. Go to [vercel.com](https://vercel.com) and click **"New Project"**
3. Import your GitHub repository
4. Vercel auto-detects Next.js — click **"Deploy"**
5. Done! Your site is live in ~60 seconds.

### Option 2: Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Install dependencies
npm install

# Deploy
vercel

# Follow prompts — when asked "Link to existing project?" select No
# Vercel will give you a live URL instantly
```

### Option 3: Local Development

```bash
npm install
npm run dev
# Open http://localhost:3000
```

## Project Structure

```
trading-terminal/
├── app/
│   ├── layout.js       # Root layout + metadata
│   ├── page.js         # Entry point
│   └── globals.css     # All styles
├── components/
│   ├── TradingApp.js   # Main app shell + navigation
│   ├── SignalDashboard.js  # Charts + signal analysis
│   └── ChecklistPage.js    # Trade checklist
├── package.json
├── next.config.mjs
└── vercel.json
```

## Customization

### Add Real Signal Data
In `SignalDashboard.js`, replace the `generateSignals()` function with a real API call to your data provider (e.g., Twelve Data, Alpha Vantage, Binance WebSocket).

### Change Pairs
In `SignalDashboard.js`, update the `PAIRS` object with any TradingView symbol (e.g., `BINANCE:ETHUSDT`, `FX:EURUSD`).

### Modify Checklist
In `ChecklistPage.js`, edit `CHECKLIST_GROUPS` to customize checklist items for your strategy.
